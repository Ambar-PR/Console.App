﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace CustomerConsoleApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // URL del endpoint de tu servicio web API donde se maneja la creación de clientes
            string apiUrl = "https://localhost:44334/swagger/index.html";

            // Datos del cliente que deseas enviar
            var customer = new
            {
                TipoDocumento = 2,
                Documento = 6341,
                Nombres = "Maria",
                Apellidos = "Lopez",
                FechaNacimiento = "1998-05-03"
            };

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Enviar la solicitud HTTP POST con los datos del cliente
                    HttpResponseMessage response = await client.PostAsJsonAsync(apiUrl, customer);

                    // Verificar si la solicitud fue exitosa
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Customer registered successfully.");
                    }
                    else
                    {
                        Console.WriteLine($"Error registering customer. Status code: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
